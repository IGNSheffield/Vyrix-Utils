package me.yolosanta.commands;

import me.yolosanta.utils.Messages;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class SpeedCommand extends BukkitCommand {

    public SpeedCommand(String name) {
        super(name);
        setPermission("vyrixutils.command.speed");
        setAliases(Arrays.asList("sp"));
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player) sender;
        if (!testPermission(player)) {
            return true;
        }

        if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            player.removePotionEffect(PotionEffectType.SPEED);

            player.sendMessage(Messages.MESSAGE_SPEED_DISABLED);
        } else {
            player.addPotionEffects(Arrays.asList(
                    new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, Messages.SPEED_LEVEL)
            ));

            player.sendMessage(Messages.MESSAGE_SPEED_ENABLED);
        }
        return true;
    }
}
