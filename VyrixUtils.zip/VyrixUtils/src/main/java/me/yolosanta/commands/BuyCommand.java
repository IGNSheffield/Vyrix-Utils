package me.yolosanta.commands;

import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;

public class BuyCommand extends BukkitCommand {

    public BuyCommand(String name) {
        super(name);
        setPermission("vyrixutils.command.buy");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player) sender;
        if (!testPermission(player)) {
            return true;
        }


        return true;
    }
}
