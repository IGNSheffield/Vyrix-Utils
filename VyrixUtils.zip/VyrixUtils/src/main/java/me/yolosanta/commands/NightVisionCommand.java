package me.yolosanta.commands;

import me.yolosanta.utils.Messages;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class NightVisionCommand extends BukkitCommand {

    public NightVisionCommand(String name) {
        super(name);
        setPermission("vyrixutils.command.nightvision");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player) sender;
        if (!testPermission(player)) {
            return true;
        }

        if (player.hasPotionEffect(PotionEffectType.NIGHT_VISION)) {
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);

            player.sendMessage(Messages.MESSAGE_NIGHT_VISION_DISABLED);
        } else {
            player.addPotionEffects(Arrays.asList(
                    new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, Messages.NIGHT_VISION_LEVEL)
            ));

            player.sendMessage(Messages.MESSAGE_NIGHT_VISION_ENABLED);
        }
        return true;
    }
}
