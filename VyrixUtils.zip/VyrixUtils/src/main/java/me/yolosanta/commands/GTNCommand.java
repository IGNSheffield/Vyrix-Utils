package me.yolosanta.commands;

import me.yolosanta.VyrixUtils;
import me.yolosanta.utils.CC;
import me.yolosanta.utils.Messages;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class GTNCommand extends BukkitCommand {

    public GTNCommand(String name) {
        super(name);
        setPermission("vyrixutils.command.gtn");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player) sender;
        if (!testPermission(player)) {
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(Messages.GTN_USAGE);
            return true;
        } else {
            String value = args[0];
            if (CC.isNumber(value)) {
                int num = Integer.parseInt(value);
                if (CC.isBetween(num, Messages.GTN_MIN, Messages.GTN_MAX)) {
                    VyrixUtils.getVyrixUtils().setGTN_VAL(num);
                    VyrixUtils.getVyrixUtils().setGTN_ACTIVE(true);
                    player.sendMessage(Messages.GTN_SUCCESS);
                    for (String msg : Messages.GTN_START) {
                        Bukkit.broadcastMessage(msg);
                    }
                    Messages.GTN_COMMANDS_PREGAME.forEach(cmd -> {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                    });

                    new BukkitRunnable() {
                        @Override
                        public void run() {
                            Messages.GTN_COMMANDS_START.forEach(cmd -> {
                                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                            });
                        }
                    }.runTaskLaterAsynchronously(VyrixUtils.getVyrixUtils(), 60);
                } else {
                    player.sendMessage(Messages.GTN_NOT_IN_RANGE);
                }
            } else {
                player.sendMessage(Messages.GTN_NOT_A_NUMBER);
            }
        }

        return true;
    }
}
