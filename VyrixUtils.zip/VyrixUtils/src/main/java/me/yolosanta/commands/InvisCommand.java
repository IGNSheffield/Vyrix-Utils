package me.yolosanta.commands;

import me.yolosanta.utils.Messages;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class InvisCommand extends BukkitCommand {

    public InvisCommand(String name) {
        super(name);
        setPermission("vyrixutils.command.invis");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player) sender;
        if (!testPermission(player)) {
            return true;
        }

        if (player.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
            player.removePotionEffect(PotionEffectType.INVISIBILITY);

            player.sendMessage(Messages.MESSAGE_INVIS_DISABLED);
        } else {
            player.addPotionEffects(Arrays.asList(
                    new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, Messages.INVIS_LEVEL)
            ));

            player.sendMessage(Messages.MESSAGE_INVIS_ENABLED);
        }
        return true;
    }
}
