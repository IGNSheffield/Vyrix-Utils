package me.yolosanta.commands;

import me.yolosanta.utils.Messages;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class AllCommand extends BukkitCommand {

    public AllCommand(String name) {
        super(name);
        setPermission("vyrixutils.command.all");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player) sender;
        if (!testPermission(player)) {
            return true;
        }

        if (player.getActivePotionEffects().size() >= 1) {
            player.getActivePotionEffects().forEach(potionEffect -> player.removePotionEffect(potionEffect.getType()));
            player.sendMessage(Messages.MESSAGE_ALL_DISABLED);
        } else {
            if (Messages.ALL_FIRE_RES_ENABLED) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, Messages.FIRE_RES_LEVEL));
            }
            if (Messages.ALL_INVIS_ENABLED) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, Messages.INVIS_LEVEL));
            }
            if (Messages.ALL_NIGHT_VISION_ENABLED) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, Messages.NIGHT_VISION_LEVEL));
            }
            if (Messages.ALL_SPEED_ENABLED) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, Messages.SPEED_LEVEL));
            }
            player.sendMessage(Messages.MESSAGE_ALL_ENABLED);
        }
        return true;
    }
}
