package me.yolosanta.commands;

import me.yolosanta.utils.Messages;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;

public class FireResCommand extends BukkitCommand {

    public FireResCommand(String name) {
        super(name);
        setPermission("vyrixutils.command.fire");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player) sender;
        if (!testPermission(player)) {
            return true;
        }

        if (player.hasPotionEffect(PotionEffectType.FIRE_RESISTANCE)) {
            player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);

            player.sendMessage(Messages.MESSAGE_FIRE_RES_DISABLED);
        } else {
            player.addPotionEffects(Arrays.asList(
                    new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, Messages.FIRE_RES_LEVEL)
            ));

            player.sendMessage(Messages.MESSAGE_FIRE_RES_ENABLED);
        }
        return true;
    }
}
