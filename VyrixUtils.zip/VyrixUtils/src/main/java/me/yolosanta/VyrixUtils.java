package me.yolosanta;

import lombok.Getter;
import lombok.Setter;
import me.yolosanta.commands.*;
import me.yolosanta.events.GTNEvents;
import me.yolosanta.utils.BasicConfigurationFile;
import me.yolosanta.utils.CommandHandler;
import me.yolosanta.utils.Messages;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

@Getter
public class VyrixUtils extends JavaPlugin {

    @Getter
    private static VyrixUtils vyrixUtils;

    private BasicConfigurationFile configFile;

    @Setter
    private int GTN_VAL = 0;
    @Setter
    private boolean GTN_ACTIVE = false;

    @Override
    public void onEnable() {
        vyrixUtils = this;

        configFile = new BasicConfigurationFile(this, "config");

        if (configFile.getBoolean("Commands.All.Enabled")) {
            new CommandHandler(new AllCommand("all"), "all");
        }

        if (configFile.getBoolean("Commands.Fire-Res.Enabled")) {
            new CommandHandler(new FireResCommand("fr"), "fr");
        }

        if (configFile.getBoolean("Commands.Invis.Enabled")) {
            new CommandHandler(new InvisCommand("invis"), "invis");
        }

        if (configFile.getBoolean("Commands.Night-Vision.Enabled")) {
            new CommandHandler(new NightVisionCommand("nv"), "nv");
        }

        if (configFile.getBoolean("Commands.Speed.Enabled")) {
            new CommandHandler(new SpeedCommand("speed"), "speed");
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : getServer().getOnlinePlayers()) {
                    for (PotionEffect effects : player.getActivePotionEffects()) {
                        int secondsRemaining = (effects.getDuration() / 20);

                        if (effects.getType().equals(PotionEffectType.SPEED)) {
                            if (secondsRemaining == 0) {
                                player.removePotionEffect(PotionEffectType.SPEED);
                                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, Messages.SPEED_LEVEL));
                            }
                        }

                        if (effects.getType().equals(PotionEffectType.FIRE_RESISTANCE)) {
                            if (secondsRemaining <= 0) {
                                player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
                                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, Messages.FIRE_RES_LEVEL));
                            }
                        }

                        if (effects.getType().equals(PotionEffectType.INVISIBILITY)) {
                            if (secondsRemaining <= 0) {
                                player.removePotionEffect(PotionEffectType.INVISIBILITY);
                                player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, Messages.INVIS_LEVEL));
                            }
                        }

                        if (effects.getType().equals(PotionEffectType.NIGHT_VISION)) {
                            if (secondsRemaining <= 0) {
                                player.removePotionEffect(PotionEffectType.NIGHT_VISION);
                                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, Messages.NIGHT_VISION_LEVEL));
                            }
                        }
                    }
                }
            }
        }.runTaskTimerAsynchronously(this, 0, 20L);

        if (Messages.GTN_ENABLED) {
            getServer().getPluginManager().registerEvents(new GTNEvents(), this);
            new CommandHandler(new GTNCommand("gtn"), "gtn");
        }
    }
}
