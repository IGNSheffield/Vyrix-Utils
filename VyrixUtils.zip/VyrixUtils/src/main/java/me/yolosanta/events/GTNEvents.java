package me.yolosanta.events;

import me.yolosanta.VyrixUtils;
import me.yolosanta.utils.CC;
import me.yolosanta.utils.Messages;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class GTNEvents implements Listener {

    @EventHandler
    public void onGuess(AsyncPlayerChatEvent event) {
        String msg = event.getMessage();
        if (VyrixUtils.getVyrixUtils().isGTN_ACTIVE()) {
            if (CC.isNumber(msg)) {
                int val = Integer.parseInt(msg);
                int toGuess = VyrixUtils.getVyrixUtils().getGTN_VAL();
                if (val == toGuess ) {
                    VyrixUtils.getVyrixUtils().setGTN_ACTIVE(false);
                    Messages.GTN_COMMANDS_WINNER.forEach(cmd -> {
                        cmd = cmd
                                .replace("%player%", event.getPlayer().getName())
                                .replace("%number%", String.valueOf(VyrixUtils.getVyrixUtils().getGTN_VAL()));
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                    });
                }
            }
        }
    }
}
