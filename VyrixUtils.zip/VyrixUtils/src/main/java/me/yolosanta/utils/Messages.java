package me.yolosanta.utils;

import me.yolosanta.VyrixUtils;

import java.util.List;

public class Messages {

    private static final BasicConfigurationFile configFile = VyrixUtils.getVyrixUtils().getConfigFile();

    public static boolean ALL_SPEED_ENABLED;
    public static boolean ALL_INVIS_ENABLED;
    public static boolean ALL_FIRE_RES_ENABLED;
    public static boolean ALL_NIGHT_VISION_ENABLED;
    public static String MESSAGE_ALL_ENABLED;
    public static String MESSAGE_ALL_DISABLED;
    public static int SPEED_LEVEL;
    public static String MESSAGE_SPEED_ENABLED;
    public static String MESSAGE_SPEED_DISABLED;
    public static int INVIS_LEVEL;
    public static String MESSAGE_INVIS_ENABLED;
    public static String MESSAGE_INVIS_DISABLED;
    public static int FIRE_RES_LEVEL;
    public static String MESSAGE_FIRE_RES_ENABLED;
    public static String MESSAGE_FIRE_RES_DISABLED;
    public static int NIGHT_VISION_LEVEL;
    public static String MESSAGE_NIGHT_VISION_ENABLED;
    public static String MESSAGE_NIGHT_VISION_DISABLED;

    public static boolean GTN_ENABLED;
    public static int GTN_MAX;
    public static int GTN_MIN;
    public static String GTN_USAGE;
    public static String GTN_NOT_IN_RANGE;
    public static String GTN_NOT_A_NUMBER;
    public static String GTN_SUCCESS;
    public static List<String> GTN_START;
    public static List<String> GTN_COMMANDS_PREGAME;
    public static List<String> GTN_COMMANDS_START;
    public static List<String> GTN_COMMANDS_WINNER;

    static {
        ALL_SPEED_ENABLED = configFile.getBoolean("Commands.All.Speed");
        ALL_INVIS_ENABLED = configFile.getBoolean("Commands.All.Invis");
        ALL_FIRE_RES_ENABLED = configFile.getBoolean("Commands.All.Fire-Res");
        ALL_NIGHT_VISION_ENABLED = configFile.getBoolean("Commands.All.Night-Vision");

        MESSAGE_ALL_ENABLED = CC.toColor(configFile.getString("Commands.All.Messages.Enabled"));
        MESSAGE_ALL_DISABLED = CC.toColor(configFile.getString("Commands.All.Messages.Disabled"));

        SPEED_LEVEL = (configFile.getInteger("Commands.Speed.Level") - 1);
        MESSAGE_SPEED_ENABLED = CC.toColor(configFile.getString("Commands.Speed.Messages.Enabled"));
        MESSAGE_SPEED_DISABLED = CC.toColor(configFile.getString("Commands.Speed.Messages.Disabled"));

        INVIS_LEVEL = (configFile.getInteger("Commands.Invis.Level") - 1);
        MESSAGE_INVIS_ENABLED = CC.toColor(configFile.getString("Commands.Invis.Messages.Enabled"));
        MESSAGE_INVIS_DISABLED = CC.toColor(configFile.getString("Commands.Invis.Messages.Disabled"));

        FIRE_RES_LEVEL = (configFile.getInteger("Commands.Fire-Res.Level") - 1);
        MESSAGE_FIRE_RES_ENABLED = CC.toColor(configFile.getString("Commands.Fire-Res.Messages.Enabled"));
        MESSAGE_FIRE_RES_DISABLED = CC.toColor(configFile.getString("Commands.Fire-Res.Messages.Disabled"));

        NIGHT_VISION_LEVEL = (configFile.getInteger("Commands.Night-Vision.Level") - 1);
        MESSAGE_NIGHT_VISION_ENABLED = CC.toColor(configFile.getString("Commands.Night-Vision.Messages.Enabled"));
        MESSAGE_NIGHT_VISION_DISABLED = CC.toColor(configFile.getString("Commands.Night-Vision.Messages.Disabled"));

        GTN_ENABLED = configFile.getBoolean("Commands.Guess-The-Number.Enabled");
        GTN_MIN = configFile.getInteger("Commands.Guess-The-Number.Min");
        GTN_MAX = configFile.getInteger("Commands.Guess-The-Number.Max");
        GTN_USAGE = CC.toColor(configFile.getString("Commands.Guess-The-Number.Messages.Usage"));
        GTN_NOT_IN_RANGE = CC.toColor(configFile.getString("Commands.Guess-The-Number.Messages.Not-In-Range"));
        GTN_NOT_A_NUMBER = CC.toColor(configFile.getString("Commands.Guess-The-Number.Messages.Not-A-Number"));
        GTN_SUCCESS = CC.toColor(configFile.getString("Commands.Guess-The-Number.Messages.Success"));
        GTN_START = CC.toColor(configFile.getStringList("Commands.Guess-The-Number.Messages.Start"));
        GTN_COMMANDS_PREGAME = CC.toColor(configFile.getStringList("Commands.Guess-The-Number.Messages.Commands-Pregame"));
        GTN_COMMANDS_START = CC.toColor(configFile.getStringList("Commands.Guess-The-Number.Messages.Commands-Start"));
        GTN_COMMANDS_WINNER = CC.toColor(configFile.getStringList("Commands.Guess-The-Number.Messages.Commands-Winner"));
    }
}
