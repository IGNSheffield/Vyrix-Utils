package me.yolosanta.utils;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandMap;
import org.bukkit.command.defaults.BukkitCommand;

import java.lang.reflect.Field;

public class CommandHandler {

    private BukkitCommand bukkitCommand;
    private String name;

    public CommandHandler(BukkitCommand bukkitCommand, String name) {
        this.bukkitCommand = bukkitCommand;
        this.name = name;

        setup();
    }

    public void setup() {
        Field bukkitCommandMap = null;
        try {
            bukkitCommandMap = Bukkit.getServer().getClass().getDeclaredField("commandMap");
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
        if (bukkitCommandMap != null) {
            bukkitCommandMap.setAccessible(true);
        }
        CommandMap commandMap = null;
        try {
            if (bukkitCommandMap != null) {
                commandMap = (CommandMap) bukkitCommandMap.get(Bukkit.getServer());
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        if (commandMap != null) {
            commandMap.register(name, bukkitCommand);
        }
    }
}
