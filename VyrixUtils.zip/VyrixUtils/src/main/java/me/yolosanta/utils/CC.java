package me.yolosanta.utils;

import org.apache.commons.lang.math.NumberUtils;
import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;

public class CC {

    public static String toColor(String str) {
        return ChatColor.translateAlternateColorCodes('&', str);
    }

    public static List<String> toColor(List<String> list) {
        List<String> cacheList = new ArrayList<>();
        if (list == null) return new ArrayList<>();
        for (String s : list) {
            cacheList.add(toColor(s));
        }
        return cacheList;
    }

    public static boolean isBetween(int number, int min, int max) {
        return (number >= min && number <= max);
    }

    public static boolean isNumber(String number) {
        return NumberUtils.isNumber(number);
    }
}
